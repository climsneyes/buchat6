# config.py
OPENAI_API_KEY = "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"
MODEL_NAME = "gpt-4o-mini"

# --- Firebase 설정 ---
FIREBASE_DB_URL = "https://pychat-25c45-default-rtdb.asia-southeast1.firebasedatabase.app/"
FIREBASE_KEY_PATH = "firebase_key.json"
